/*
Template Name: Nazox -  Admin & Dashboard Template
Author: Themesdesign
Contact: themesdesign.in@gmail.com
File: Form mask Js File
*/

$(document).ready(function(){
    $(".input-mask").inputmask();
});